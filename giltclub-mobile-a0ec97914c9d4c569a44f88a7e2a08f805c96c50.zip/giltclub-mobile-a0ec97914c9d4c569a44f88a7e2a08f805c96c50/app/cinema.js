export function renderCinema(){
  const content = document.getElementById("content");

  content.innerHTML = `
    <h2>Cinema</h2>
    <p>Realtime voice room ready.</p>
  `;
}
