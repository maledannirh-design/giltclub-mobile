export const CANCEL_POLICY = {
  fullRefundHours: 48,
  halfRefundStart: 36,
  halfRefundEnd: 48
};
